% OFDM DVB-T2 with AWGN simulation
clear all; close all;

% OFDM parameters
Nc = 6817;      % number of subcarriers
Nfft = 8192;    % FFT size
Ncp = 2048;     % cyclic prefix length
Ns = Nfft + Ncp; % OFDM symbol length
M = 32;         % modulation order

% DVB-T2 parameters
cr = 2;       % code rate
L = 128;        % FEC block length
K = 4; % FEC information length
%puncturing_pattern = [1 1 1 0 1]; % puncturing pattern for 3/5 code rate

% Signal generation
data = randi([0 M-1], K, 1); % random data
tx_symbols = qammod(data, M, 'gray'); % QAM modulation
tx_bits = de2bi(data, log2(M)); % bit mapping
tx_bits = reshape(tx_bits.', [], 1); % serial bit stream
padded_bits = [tx_bits; zeros(mod(-length(tx_bits), Nc), 1)]; % zero-padding
ofdm_symbols = ifft(reshape(padded_bits, Nc, []).', Nfft); % IFFT
%ofdm_symbols = [ofdm_symbols(:, end-Ncp+1:end) ofdm_symbols]; % cyclic prefix

% Channel simulation
SNR = 0:1:30; % range of SNR values
EbNo = 10.^(SNR/10);
ber = zeros(size(EbNo)); % preallocate BER vector
for n = 1:length(EbNo)
    snr = EbNo(n) %+ 10*log10(log2(M)*K/Ns); % SNR per subcarrier
    rx_symbols = awgn(ofdm_symbols, snr, 'measured'); % AWGN channel
    %rx_symbols = rx_symbols(:, Ncp+1:end); % remove cyclic prefix
    rx_symbols = fft(rx_symbols, Nfft); % FFT
    rx_symbols = rx_symbols(:); % parallel to serial conversion
    rx_bits = qamdemod(rx_symbols, M, 'gray'); % QAM demodulation
    %rx_bits = reshape(de2bi(rx_bits, log2(M)).', [], 1); % bit mapping
    rx_bits = rx_bits(1:length(tx_bits)); % remove zero-padding
     %ber(n) = biterr(tx_bits, rx_bits); % BER calculation
     ber(n) = biterr(tx_bits, rx_bits,5); % BER calculation
     
end

% Plot results
semilogy(EbNo, ber);
grid on;
xlabel('Eb/No (dB)');
ylabel('BER');
title('OFDM DVB-T2 with AWGN');
