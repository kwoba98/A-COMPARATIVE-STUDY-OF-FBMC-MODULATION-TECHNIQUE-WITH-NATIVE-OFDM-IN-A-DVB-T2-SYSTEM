% Set up parameters
N = 64;                     % Number of subcarriers
n_symbols = 1000;           % Number of FBMC symbols to transmit
SNR = 10;                   % Signal-to-Noise Ratio (dB)
beta = 0.5;                 % Roll-off factor
h = rcosdesign(beta, 6, N); % Raised cosine filter coefficients
K = length(h);              % Filter length

% Generate random QPSK symbols to transmit
tx_symbols = 2*randi([0 1], N, n_symbols) - 1 + 1i*(2*randi([0 1], N, n_symbols) - 1);

% Perform FBMC modulation on the transmitted symbols
tx_ofdm_symbols = zeros(K*N, n_symbols);
for i = 1:n_symbols
    tx_ofdm_symbols(:,i) = ifft(filter(h, 1, fft(tx_symbols(:,i), N*K)), N*K);
end

% Add AWGN to the signal
rx_serial = awgn(tx_ofdm_symbols(:), SNR, 'measured');

% Perform FBMC demodulation on the received signal
rx_ofdm_symbols = reshape(rx_serial, K*N, n_symbols);
rx_symbols = zeros(N, n_symbols);
for i = 1:n_symbols
    rx_symbols(:,i) = fft(filter(h, 1, ifft(rx_ofdm_symbols(:,i), N*K)), N);
end

% Calculate PSD of received signal
[Pxx, f] = periodogram(rx_serial, rectwin(length(rx_serial)), 1024, 1);

% Plot PSD
figure;
plot(f, 10*log10(Pxx));
title('PSD of FBMC Signal in AWGN Channel');
xlabel('Frequency (Hz)');
ylabel('Power Spectral Density (dB/Hz)');


%This code generates random QPSK symbols and performs FBMC modulation on them using a raised cosine filter with a specified roll-off factor. The transmitted signal is then corrupted by AWGN with a specified SNR. The received signal is demodulated and the PSD is calculated using the periodogram function. Finally, the PSD is plotted using MATLAB's plot function.