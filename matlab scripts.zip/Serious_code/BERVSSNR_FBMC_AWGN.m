clear all; close all;

% FBMC parameters
N = 8192;           % number of samples per symbol
M = 64;             % modulation order
O = 16;             % oversampling factor
K1 = 256;           % filter length for pulse shaping
g = rcosdesign(0.5, 6, O, 'sqrt'); % prototype filter
g = g/sqrt(sum(g.^2)); % normalize filter

% DVB-T2 parameters
cr = 3/5;           % code rate
L = 128;            % FEC block length
K = round(cr*L);    % FEC information length
puncturing_pattern = [1 1 1 0 1 0]; % puncturing


% Signal generation
data = randi([0 M-1], K, 1); % random data
tx_symbols = qammod(data, M, 'gray'); % QAM modulation
tx_bits = de2bi(data, log2(M)); % bit mapping
tx_bits = reshape(tx_bits.', [], 1); % serial bit stream
padded_bits = [tx_bits; zeros(mod(-length(tx_bits), N/O), 1)]; % zero-padding
ofdm_symbols = ifft(reshape(padded_bits, N/O, []).', N); % IFFT
tx_symbols = reshape(ofdm_symbols, [], 1); % parallel to serial conversion
tx_symbols = filter(g, 1, [tx_symbols; zeros(K1-1, 1)]); % pulse shaping

% Channel simulation
EbNo = 0:0.1:20; % range of SNR values with smaller increment

ber = zeros(size(EbNo)); % preallocate BER vector
for n = 1:length(EbNo)
    snr = EbNo(n) + 10*log10(log2(M)*N/K1); % SNR per sample
    rx_symbols = awgn(tx_symbols, snr, 'measured'); % AWGN channel
    rx_symbols = filter(g, 1, [rx_symbols; zeros(K1-1, 1)]); % matched filter
    rx_symbols = rx_symbols(K1:O:end); % downsample
    rx_symbols = reshape(rx_symbols, [], 1); % parallel to serial conversion
    rx_bits = qamdemod(rx_symbols, M, 'gray'); % QAM demodulation
    rx_bits = reshape(de2bi(rx_bits, log2(M)).', [], 1); % bit mapping
    rx_bits = rx_bits(1:length(tx_bits)); % remove zero-padding
    [~, ber(n)] = biterr(tx_bits, rx_bits); % BER calculation
end

% Plot results
semilogy(EbNo, ber, '-o');
grid on;
xlabel('Eb/No (dB)');
ylabel('BER');
title('FBMC DVB-T2 with AWGN');
