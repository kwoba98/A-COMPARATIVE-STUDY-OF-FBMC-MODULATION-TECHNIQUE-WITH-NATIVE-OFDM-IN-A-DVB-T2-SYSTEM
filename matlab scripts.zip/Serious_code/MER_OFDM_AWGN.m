% System parameters
N = 2048; % Number of subcarriers
M = 64; % Modulation order (QAM)
alpha = 0.25; % Roll-off factor for raised cosine filter

% Range of SNRs to be simulated
SNR_dB_min = 0;
SNR_dB_max = 30;
SNR_dB_step = 5;
SNR_dB_range = SNR_dB_min:SNR_dB_step:SNR_dB_max;

% Preallocate memory for the results
num_runs = 1000; % Increase number of runs
MER_all = zeros(num_runs, length(SNR_dB_range));

for k = 1:num_runs
    % Generate random data
    data = randi([0 M-1],N,1);

    % Modulate the data using QAM
    modulated_data = qammod(data,M);

    % Perform IFFT on the modulated data to obtain the time-domain signal
    ifft_data = ifft(modulated_data);

    % Add cyclic prefix to the time-domain signal
    cp_len = length(ifft_data)/4;
    cp_data = [ifft_data(end-cp_len+1:end,:);ifft_data];

    % Convert the time-domain signal to a serial stream
    tx_signal = cp_data(:);

    % Loop over different SNRs
    for i = 1:length(SNR_dB_range)
        SNR_dB = SNR_dB_range(i);

        % Add AWGN to the signal
        noise = randn(size(tx_signal));
        noise_power = sum(abs(noise).^2)/length(noise);
        signal_power = sum(abs(tx_signal).^2)/length(tx_signal);
        SNR = signal_power/noise_power;
        desired_SNR = 10^(SNR_dB/10);
        scale_factor = sqrt(desired_SNR/SNR);
        rx_signal = tx_signal + scale_factor*noise;

        % Convert the received signal to a matrix
        rx_signal_matrix = reshape(rx_signal,N+cp_len,[]);

        % Remove the cyclic prefix from the received signal
        rx_signal_matrix = rx_signal_matrix(cp_len+1:end,:);

        % Perform FFT on the received signal to obtain the frequency-domain signal
        fft_data = fft(rx_signal_matrix);

        % Demodulate the received signal
        demodulated_data = qamdemod(fft_data,M);

        % Calculate the MER
        signal_power = sum(abs(modulated_data).^2)/length(modulated_data);
        error_power = sum(abs(modulated_data - demodulated_data).^2)/length(modulated_data);
        MER_all(k,i) = 10*log10(signal_power/error_power);
    end
end

% Average the results over multiple runs
MER_avg = mean(MER_all);

% Plot the MER vs. SNR
plot(SNR_dB_range,MER_avg);
xlabel('SNR (dB)');
ylabel('MER (dB)');
title('OFDM system with AWGN in DVB-T2');
