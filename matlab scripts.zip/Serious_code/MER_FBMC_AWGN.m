% Parameters
numFrames = 100; % Number of frames to simulate
numSubcarriers = 2048; % Number of subcarriers
numSymbols = 32; % Number of symbols per frame
modulationOrder = 4; % Modulation order (QPSK)
filterLength = 64; % Filter length
oversamplingFactor = 4; % Oversampling factor
channelBandwidth = 8e6; % Channel bandwidth (Hz)
pilotSpacing = 8; % Pilot spacing (in subcarriers)

% Generate filter coefficients
prototypeFilter = rcosdesign(0.5, filterLength, oversamplingFactor);
numFilters = numSubcarriers / oversamplingFactor;
filters = repmat(prototypeFilter, 1, numFilters);

% Generate pilot symbols
pilotSymbols = repmat(qammod(0:3, modulationOrder), numFilters/pilotSpacing, 1);
pilotIndices = 1:pilotSpacing:numSubcarriers;
pilotSubcarriers = false(numSubcarriers, 1);
pilotSubcarriers(pilotIndices) = true;

% Generate data symbols
dataSymbols = randi([0, modulationOrder-1], numSubcarriers-numel(pilotIndices), numSymbols);
dataSymbols = qammod(dataSymbols, modulationOrder);

% Generate FBMC signals
txSignals = zeros(numSubcarriers, numSymbols);
for i = 1:numSymbols
    dataSubcarriers = ~pilotSubcarriers;
    dataIndices = find(dataSubcarriers);
    numPilotSymbols = ceil(numSubcarriers/pilotSpacing);
    pilotSymbols = repmat(qammod(0:3, modulationOrder), 1, numPilotSymbols);
    txSignals(dataIndices, i) = dataSymbols(:, i);
    txSignals(pilotSubcarriers, i) = pilotSymbols(:, mod(i-1, numPilotSymbols)+1);
    txSignals(:, i) = ifft(txSignals(:, i)) / sqrt(numSubcarriers);
end

% Generate noise
snr = 0:2:30;
noiseVariances = 10.^(-snr/10);
numSNRs = numel(snr);
mer = zeros(numSNRs, 1);
for i = 1:numSNRs
    noise = sqrt(noiseVariances(i)/2) * (randn(numSubcarriers, numSymbols) + 1j*randn(numSubcarriers, numSymbols));
    rxSignals = txSignals + noise;
    filterMatrix = repmat(filters.', numSymbols, 1);
    rxSignals = conv2(rxSignals, filterMatrix, 'same');
    rxSignals = fft(rxSignals) * sqrt(numSubcarriers);
    dataSymbolsEst = rxSignals(dataSubcarriers, :) ./ txSignals(dataSubcarriers, :);
    dataSymbolsEst = qamdemod(dataSymbolsEst, modulationOrder);
    dataSymbolsEst = reshape(dataSymbolsEst, [], 1);
    dataSymbols = reshape(dataSymbols, [], 1);
    mer(i) = 20*log10(norm(dataSymbols)/norm(dataSymbols - dataSymbolsEst));
end

% Plot results
figure;
plot(snr, mer, '-o', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('SNR (dB)');
ylabel('MER (dB)');
grid on;
